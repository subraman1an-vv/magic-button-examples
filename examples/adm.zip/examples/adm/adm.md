Application Dependency Management (ADM) detects security vulnerabilities in application dependencies.

ADM relies on scores provided by the Common Vulnerability Scoring System: an open framework for communicating the characteristics and severity of software vulnerabilities. ADM is configured in the "Managed Build" stage of a DevOps pipeline.